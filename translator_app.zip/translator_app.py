#Real time Speech and Text Translator
#AI Semester Project

import tkinter as tk
from tkinter import ttk, messagebox
import speech_recognition as sr
from googletrans import Translator, LANGUAGES
import mysql.connector
import threading
from langdetect import detect


#Database Connection
def insert_translation_to_db(original_text, original_lang, translated_text, translated_lang):
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",             
            password="fa23BCS0433A",
            database="translator_app",
            charset='utf8mb4',
            use_unicode=True
        )
        cursor = conn.cursor()
        query = """
        INSERT INTO translations (original_text, original_lang, translated_text, translated_lang)
        VALUES (%s, %s, %s, %s)
        """
        cursor.execute(query, (
            original_text,
            original_lang,
            translated_text,
            translated_lang
          ))

        conn.commit()
        cursor.close()
        conn.close()
    except mysql.connector.Error as err:
        print(f"MySQL Error: {err}")

# Language mapping
language_codes = {name.title(): code for code, name in LANGUAGES.items()}

#Get speech code
def get_speech_code(lang_code):
    return lang_code + "-IN" if '-' not in lang_code else lang_code

#Voice-translate function
def voice_translate():
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    input_lang_name = input_lang_var.get()
    output_lang_name = output_lang_var.get()

    input_code = language_codes[input_lang_name]
    output_code = language_codes[output_lang_name]
    speech_code = get_speech_code(input_code)

    with microphone as source:
        status_var.set("🎧 Listening...")
        root.update()
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source, timeout=10, phrase_time_limit=10)


    try:
        status_var.set("🧠 Recognizing...")
        root.update()
        spoken = recognizer.recognize_google(audio, language=speech_code)

        translator = Translator()
        translated = translator.translate(spoken, src=input_code, dest=output_code)

        output_box.config(state='normal')
        output_box.delete(1.0, tk.END)
        output_box.insert(tk.END, f"🔊 You said ({input_lang_name}):\n{spoken}\n\n🌐 Translated ({output_lang_name}):\n{translated.text}")
        output_box.config(state='disabled')
        status_var.set("✅ Voice Translation Done")
        insert_translation_to_db(spoken, input_lang_name, translated.text, output_lang_name)


    except sr.UnknownValueError:
        messagebox.showerror("Error", "Could not understand the audio.")
        status_var.set("⚠ Try Again")
    except sr.RequestError:
        messagebox.showerror("Error", "Check your internet connection.")
        status_var.set("❌ Request Failed")
    except Exception as e:
        messagebox.showerror("Error", str(e))
        status_var.set("❌ Error")

#Manual Translate Function
def manual_translate():
    input_text = input_text_box.get("1.0", tk.END).strip()
    if not input_text:
        messagebox.showwarning("Warning", "Please enter some text to translate.")
        return
    try:
       detected_lang_code = detect(input_text)
    except Exception as e:
        messagebox.showerror("Detection Error", f"Could not detect language. Error: {str(e)}")
        return

    input_lang_name = input_lang_var.get()
    output_lang_name = output_lang_var.get()
    input_code = language_codes[input_lang_name]
    output_code = language_codes[output_lang_name]
    
    if detected_lang_code != input_code:
        actual_lang = LANGUAGES.get(detected_lang_code, "Unknown").title()
        messagebox.showerror("Language Mismatch",
            f" The text appears to be in '{actual_lang}', but you selceted '{input_lang_name}'.\n\n"
            f"Please select the correct input language or enter text accordingly.")
        return

    # Default: use Google Translate for all other languages
    try:
        translator = Translator()
        translated = translator.translate(input_text, src=input_code, dest=output_code)

        output_box.config(state='normal')
        output_box.delete(1.0, tk.END)
        output_box.insert(tk.END, f"📝 You wrote ({input_lang_name}):\n{input_text}\n\n🌐 Translated ({output_lang_name}):\n{translated.text}")
        output_box.config(state='disabled')
        status_var.set("✅ Text Translation Done")
        insert_translation_to_db(input_text, input_lang_name, translated.text, output_lang_name)

    except Exception as e:
        messagebox.showerror("Translation Error", str(e))
        status_var.set("❌ Error")

        

# GUI setup
root = tk.Tk()
root.title("🌐 Elegant Voice & Text Translator")
root.geometry("740x620")
root.resizable(False, False)
root.configure(bg="#e8f0fe")

# Title Frame
title_frame = tk.Frame(root, bg="#1a73e8")
title_frame.pack(fill=tk.X)

title_label = tk.Label(title_frame, text="🎤📝 Voice & Text Translator", font=("Segoe UI", 20, "bold"),
                       fg="white", bg="#1a73e8", pady=15)
title_label.pack()

# Language selection
lang_frame = tk.Frame(root, bg="#e8f0fe")
lang_frame.pack(pady=20)

tk.Label(lang_frame, text="From:", font=("Segoe UI", 12), bg="#e8f0fe").grid(row=0, column=0, padx=10)
input_lang_var = tk.StringVar(value="English")
input_dropdown = ttk.Combobox(lang_frame, textvariable=input_lang_var, values=sorted(language_codes.keys()), state='readonly', width=20)
input_dropdown.grid(row=0, column=1, padx=10)

tk.Label(lang_frame, text="To:", font=("Segoe UI", 12), bg="#e8f0fe").grid(row=0, column=2, padx=10)
output_lang_var = tk.StringVar(value="Urdu")
output_dropdown = ttk.Combobox(lang_frame, textvariable=output_lang_var, values=sorted(language_codes.keys()), state='readonly', width=20)
output_dropdown.grid(row=0, column=3, padx=10)

# Input text box for manual typing
tk.Label(root, text="📝 Type Text to Translate:", font=("Segoe UI", 12, "bold"), bg="#e8f0fe", anchor='w').pack(padx=20, anchor='w')
input_text_box = tk.Text(root, height=4, width=85, font=("Segoe UI", 11), wrap=tk.WORD)
input_text_box.pack(pady=5)

# Buttons for voice and manual translation
button_frame = tk.Frame(root, bg="#e8f0fe")
button_frame.pack(pady=10)

voice_btn = tk.Button(button_frame, text="🎙 Voice Translate", font=("Segoe UI", 12, "bold"),
                      command=lambda: threading.Thread(target=voice_translate).start(),
                      bg="#1a73e8", fg="white", width=20, relief=tk.FLAT)

voice_btn.grid(row=0, column=0, padx=10)

text_btn = tk.Button(button_frame, text="📤 Translate Text", font=("Segoe UI", 12, "bold"),
                     command=manual_translate, bg="#34a853", fg="white", width=20, relief=tk.FLAT)
text_btn.grid(row=0, column=1, padx=10)

# Output text
output_box = tk.Text(root, font=("Segoe UI", 12), height=10, width=85, wrap=tk.WORD, bg="white", fg="black", relief=tk.GROOVE, bd=2)
output_box.pack(pady=10)
output_box.config(state='disabled')

# Status label
status_var = tk.StringVar(value="")
status_label = tk.Label(root, textvariable=status_var, font=("Segoe UI", 10), bg="#e8f0fe", fg="green")
status_label.pack(pady=5)

# Footer
footer = tk.Label(root, text="Created with 💙 using Python & Google Translator", font=("Segoe UI", 9), bg="#e8f0fe", fg="#555")
footer.pack(side=tk.BOTTOM, pady=5)

root.mainloop()

